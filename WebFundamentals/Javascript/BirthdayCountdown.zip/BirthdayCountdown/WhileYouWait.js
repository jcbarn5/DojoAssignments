var days = 55;

function daysUntilMyBirthday(days) {

}
  if (days > 29) {
    console.log(days, " days until my birday. Such a long time... :(");
  }

  if (days < 30) {
    console.log(days, " days until my birday. I'm getting excited! :)");
  }

  if (days < 5) {
    console.log(days, " DAYS UNTIL MY BIRTHDAY. YYAAAAAAYYYYY! :O");
  }

  if (days == 0) {
    console.log(days, " IT'S MY BIRTHDAY. WOOOT!! \\_O_/");
  }
daysUntilMyBirthday(55);
