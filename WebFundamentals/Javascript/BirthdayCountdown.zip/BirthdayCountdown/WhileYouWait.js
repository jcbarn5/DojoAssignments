var daysUntilMyBirthday = 60;

if (daysUntilMyBirthday > 29) {
  console.log(daysUntilMyBirthday, " days until my birday. Such a long time... :(");
}

if (daysUntilMyBirthday < 30) {
  console.log(daysUntilMyBirthday, " days until my birday. I'm getting excited! :)");
}

if (daysUntilMyBirthday < 5) {
  console.log(daysUntilMyBirthday, " DAYS UNTIL MY BIRTHDAY. YYAAAAAAYYYYY! :O");
}

if (daysUntilMyBirthday == 5) {
  console.log(daysUntilMyBirthday, " IT'S MY BIRTHDAY. WOOOT!! \\_O_/");
}
