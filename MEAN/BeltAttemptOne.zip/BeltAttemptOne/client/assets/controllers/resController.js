app.controller('resController', ['beltFactory','$scope','$location','$routeParams', '$cookies', function(beltFactory, $scope, $location, $routeParams, $cookies) {



}]);
