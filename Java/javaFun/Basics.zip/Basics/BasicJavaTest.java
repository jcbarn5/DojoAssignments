public class BasicJavaTest {
  public static void main(String[] args) {
    BasicJava tester = new BasicJava();
    // System.out.println(tester.TwoFiftyFive());
    // System.out.println(tester.TwoFiftyFiveOdd());
    // System.out.println(tester.TwoFiftyFiveSum());
    // System.out.println(tester.TwoFiftyFiveSum());
    int[] arr = {1,3,4,2,9,-8,3,-4,7,-1,2,3,4,7};
    // System.out.println(tester.IterateArray(arr));
    // System.out.println(tester.TwoFiftyFiveOddArray());
    // System.out.println(tester.mma(arr));
    // System.out.println(tester.GrThanY(arr, 3));
    // System.out.println(tester.Squares(arr));
    // System.out.println(tester.ElimNeg(arr));
    System.out.println(tester.Shifting(arr));
  }
}
