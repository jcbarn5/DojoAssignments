public class PuzzleJavaTest{
  public static void main(String[] args) {
    PuzzleJava tester = new PuzzleJava();
    int[] arr = {3,5,1,2,7,9,8,13,25,32};
    String[] names = {"Nancy", "Jinichi", "Fujibayashi", "Momochi", "Ishikawa"};
    String[] alpha = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
    // System.out.println(tester.SumNTen(arr));
    // System.out.println(tester.Shuffler(names));
    // System.out.println(tester.Shuffler(names));
    // System.out.println(tester.AlphaShuff(alpha));
    // System.out.println(tester.Rando());
    // System.out.println(tester.RandoSorted());
    // System.out.println(tester.RandoStr());
    System.out.println(tester.RandoStr10());
  }
}
