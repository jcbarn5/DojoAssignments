FactoryGirl.define do
  factory :user do
    name "MyString"
    email "MyString"
    password ""
  end
end
