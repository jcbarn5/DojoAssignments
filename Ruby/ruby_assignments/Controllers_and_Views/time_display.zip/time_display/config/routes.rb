Rails.application.routes.draw do
  root "times#main"
end
