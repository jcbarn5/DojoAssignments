from django.shortcuts import render, redirect
from .models import League, Team, Player

from . import team_maker

def index(request):
	context = {
		"leagues": League.objects.all(),
		"teams": Team.objects.all(),
		"players": Player.objects.all(),

		"baseball_teams" : League.objects.filter(sport__contains="Baseball"),
		"womens_leagues" : League.objects.filter(name__contains="Womens"),
		"hockey_leagues" : League.objects.filter(sport__contains="Hockey"),
		"not_football" : League.objects.exclude(sport__contains="Football"),
		"conference_leagues" : League.objects.filter(name__contains="Conference"),
		"atlantic_leagues" : League.objects.filter(name__contains="Atlantic"),
		"Dallas_Teams" : Team.objects.filter(location__contains="Dallas"),
		"Raptor_Teams" : Team.objects.filter(team_name__contains="Raptors"),
		"City_Teams" : Team.objects.filter(location__contains="City"),
		"T_Teams" : Team.objects.filter(team_name__startswith="T"),
		"Alphabetical_Teams" : Team.objects.order_by('location'),
		"Delphabetical_Teams" : Team.objects.order_by('-team_name'),
		"Cooper_Names" : Player.objects.filter(last_name__contains="Cooper"),
		"Joshua_Names" : Player.objects.filter(first_name__contains="Joshua"),
		"CnJ_Names" : Player.objects.filter(last_name__contains="Cooper").exclude(first_name__contains="Joshua"),
		"WA_Names" : Player.objects.filter(first_name__contains="Wyatt")|Player.objects.filter(first_name__contains="Alexander"),
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
